using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HayMachine : MonoBehaviour

{
    public float movementSpeed;
    public float horizontalBoundary = 22;

    public GameObject hayBalePrefab; //Reference to the Hay Bale prefab.
    public Transform haySpawnpoint; //The point from which the hay will to be shot.
    public float shootInterval; //The smallest amount of time between shots
    private float shootTimer; //A timer that to keep track whether the machine can shoot 

    // Start is called before the first frame update
    void Start()
    {

    }

    private void UpdateMovement()
    {
        float horizontalInput = Input.GetAxisRaw("Horizontal"); // 1
        if (horizontalInput < 0 && transform.position.x > -horizontalBoundary) // 2 -----Moving to the left, i.e a -1
        {
            transform.Translate(transform.right * -movementSpeed * Time.deltaTime); //Ja que el moviment es cap a l'esquerra, �s a dir negatiu
        }
        else if (horizontalInput > 0 && transform.position.x < horizontalBoundary) // 3 ------------Moving to the right, i.e a 1 value
        {
            transform.Translate(transform.right * movementSpeed * Time.deltaTime); //Ja que el moviment es positiu, cap a la dreta

        }
    }

    private void ShootHay()
    {
        Instantiate(hayBalePrefab, haySpawnpoint.position,Quaternion.identity);
        SoundManager.Instance.PlayShootClip();
    }

    private void UpdateShooting()
    {
        shootTimer -= Time.deltaTime;
        if (shootTimer <= 0 && Input.GetKey(KeyCode.Space))
        {
            shootTimer = shootInterval;
            ShootHay();
        }
    }




    // Update is called once per frame
    void Update()
    {
        UpdateMovement();
        UpdateShooting();
    }

}